﻿
using var game = new MyGame.GameView();

game.Run();