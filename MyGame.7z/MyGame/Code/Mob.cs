﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Code
{
    public class Mob : Sprite
    {
        public new int Speed = 1;
        public Vector2 Destination;
        public Mob(Texture2D texture) : base(texture)
        {

        }

        public Mob(Texture2D texture, Vector2 position, SpriteType type) : base(texture, position, type)
        {

        }

        public override Rectangle Rectangle
        {
            get { return new Rectangle((int)Position.X, (int)Position.Y, 100, 100); }
        }

        public void Update(List<Sprite> sprites, Map map, Player player)
        {
            foreach(var sprite in sprites)
            {
                if (sprite == this)
                    continue;
                Move(map, player);
                if (sprite.Type == SpriteType.Wall)
                {
                    if ((Velocity.X > 0 && IsTouchingLeft(sprite)) ||
                    (Velocity.X < 0 & IsTouchingRight(sprite)))
                    {
                        Velocity.X = 0;
                        Destination = Vector2.Zero;
                    }
                        

                    if ((Velocity.Y > 0 && IsTouchingTop(sprite)) ||
                        (Velocity.Y < 0 & IsTouchingBottom(sprite)))
                    {
                        Velocity.Y = 0;
                        Destination = Vector2.Zero;
                    }
                        
                }   
            }
            Position += Velocity;
            Velocity = new Vector2();
        }

        private void Move(Map map, Player player)
        {
            var rnd = new Random();
            if (Destination == Vector2.Zero)
                Destination = new Vector2(Rectangle.Center.X, Rectangle.Center.Y);
            if (Math.Abs(Rectangle.X - player.Rectangle.X) < 300 && Math.Abs(Rectangle.Y - player.Rectangle.Y) < 300 
                && Destination != new Vector2(player.Position.X, player.Position.Y))
                Destination = new Vector2(player.Position.X, player.Position.Y);

            else if (Destination == new Vector2(Rectangle.Center.X, Rectangle.Center.Y)
                || Destination == new Vector2(Rectangle.X, Rectangle.Y))
            {
                int xMove = 0;
                int yMove = 0;
                while (Math.Abs(xMove) == Math.Abs(yMove))
                {
                    xMove = rnd.Next(-1, 2);
                    yMove = rnd.Next(-1, 2);
                    if ((int)Position.Y / Map.tileSize + yMove > map.Cells.Count - 1
                        || (int)Position.X / Map.tileSize + xMove > map.Cells.Count - 1
                        || (int)Position.X / Map.tileSize + xMove < 0
                        || (int)Position.Y / Map.tileSize + yMove < 0)
                        continue;
                    if (map.Cells[(int)Position.Y / Map.tileSize + yMove][(int)Position.X / Map.tileSize + xMove] == '#')
                        continue;


                }
                Destination = new Vector2(
                    (Rectangle.Center.X / Map.tileSize + xMove) * Map.tileSize + 100,
                    (Rectangle.Center.Y / Map.tileSize + yMove) * Map.tileSize + 100);
            }
            if (Position != Destination)
            {
                if (Rectangle.Center.X - Destination.X < 0)
                    Velocity.X = Speed;
                if (Rectangle.Center.X - Destination.X > 0)
                    Velocity.X = -Speed;
                if (Rectangle.Center.Y - Destination.Y > 0)
                    Velocity.Y = -Speed;
                if (Rectangle.Center.Y - Destination.Y < 0)
                    Velocity.Y = Speed;
            }
        }
    }

}
