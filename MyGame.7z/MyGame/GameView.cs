﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MyGame.Code;
using System.Collections.Generic;
using System.Linq;

namespace MyGame
{
    public class GameView : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        private Camera _camera;
        private Player _player;
        private Map _map;
        private List<Sprite> _sprites = new();
        private MiniMap _miniMap;

        public static List<Texture2D> _textures;

        public static readonly int ScreenWidth = 1280;
        public static readonly int ScreenHeight = 720;

        private LevelId ActiveLevel = LevelId.FirstLevel;

        public GameView()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            Window.IsBorderless = true;
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {

            _textures = new List<Texture2D>
            {
                Content.Load<Texture2D>("Screenshot_11"),//0
                Content.Load<Texture2D>("floor_1"),//1
                Content.Load<Texture2D>("Boy"),//2
                Content.Load<Texture2D>("wall"),//3
                Content.Load<Texture2D>("WhiteSquare"),//4
                Content.Load<Texture2D>("stairs"),//5
                Content.Load<Texture2D>("key"),//6
                Content.Load<Texture2D>("tileWithKey"),//7
                Content.Load<Texture2D>("Inventory"),//8
                Content.Load<Texture2D>("blackKey")//9
            };

            


            base.Initialize();


            _graphics.IsFullScreen = false;
            _graphics.PreferredBackBufferWidth = ScreenWidth;
            _graphics.PreferredBackBufferHeight = ScreenHeight;
            _graphics.ApplyChanges();
        }

        protected override void LoadContent()
        {

            _spriteBatch = new SpriteBatch(GraphicsDevice);

            _miniMap = new MiniMap(_textures[4], new Vector2(-300, -300));
            _map = new Map(Levels.FirstLevel.Cells, _miniMap, Levels.FirstLevel.KeyCount, Levels.FirstLevel.SpotCount);

            _player = new Player(_textures[2]);
            _player.Position = Levels.FirstLevel.StartPos;
            _player.Inventory = new Inventory(_textures[8], Levels.FirstLevel.KeyCount);

            _camera = new Camera();


            _sprites.Add(_player);
            _map.CreateSpites(_textures);
            _sprites.AddRange(_map.Sprites);

            
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            
            _camera.Follow(_player);
            _map.MiniMap.Update(_player);
            
            _player.Update(_sprites, _map);
            _player.Inventory.Update(_map.MiniMap);
            foreach (var mob in _map.Mobs)
                mob.Update(_sprites, _map, _player);

            if (!_player.IsAlive)
            {
                _miniMap = new MiniMap(_textures[4], new Vector2(-300, -300));
                _map = new Map(Levels.FirstLevel.Cells, _miniMap, Levels.FirstLevel.KeyCount, Levels.FirstLevel.SpotCount);
                _player = new Player(_textures[2]);
                _player.Position = Levels.FirstLevel.StartPos;
                _player.Inventory = new Inventory(_textures[8], Levels.FirstLevel.KeyCount);

                _sprites = new();
                _sprites.Add(_player);
                _map.CreateSpites(_textures);
                _sprites.AddRange(_map.Sprites);
            }

            if ((_map.IsAbleToLeave(_player) && Keyboard.GetState().GetPressedKeys().Contains(Keys.E)))
            {
                if (ActiveLevel == LevelId.FirstLevel)
                {
                    ActiveLevel = LevelId.SecondLevel;
                    _miniMap = new MiniMap(_textures[4], new Vector2(-300, -300));
                    _map = new Map(Levels.SecondLevel.Cells, _miniMap, Levels.SecondLevel.KeyCount, Levels.SecondLevel.SpotCount);
                    _player = new Player(_textures[2]);
                    _player.Position = Levels.SecondLevel.StartPos;
                    _player.Inventory = new Inventory(_textures[8], Levels.SecondLevel.KeyCount);

                    _sprites = new();
                    _sprites.Add(_player);
                    _map.CreateSpites(_textures);
                    _sprites.AddRange(_map.Sprites);
                }
            }



            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            
            _spriteBatch.Begin(SpriteSortMode.FrontToBack, transformMatrix: _camera.Transform);


            _map.MiniMap.Draw(_spriteBatch, _map.Visited, _map.Scale);
            _map.Convert(_spriteBatch, _player);

            foreach (var mob in _map.Mobs)
            {
                if(Map.GetPlayersVision(_player).Intersects(mob.Rectangle))
                    mob.Draw(gameTime, _spriteBatch);  
            }
                

            _player.Draw(gameTime, _spriteBatch);
            _player.Inventory.Draw(_spriteBatch);

            
            _spriteBatch.End();
            base.Draw(gameTime);
            
        }
    }
}